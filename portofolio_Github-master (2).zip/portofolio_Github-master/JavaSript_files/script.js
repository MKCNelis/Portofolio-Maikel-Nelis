document.addEventListener('DOMContentLoaded', 
    function(){
      Typed.new('.entry', {
        strings: [ "Portfolio Maikel",],
        typeSpeed: 1
      });
  });
  


