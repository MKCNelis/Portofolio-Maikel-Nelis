document.addEventListener('DOMContentLoaded', 
    function(){
      Typed.new('.entry', {
        strings: [ "Portfolio"+"<br>"+" maikel",],
        typeSpeed: 1
      });
  });
  


  document.addEventListener('DOMContentLoaded', //the second  ling of entries of scroll text
  function(){
    Typed.new('.entry2', {
      strings: [ " ​Mijn naam is Maikel Kriangsak Chandeduangdee Nelis, ik ben geboren op 21 November 1997 in Bangkok, Thailand",],
      typeSpeed: 1
    });
});
